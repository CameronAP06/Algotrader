"""
data/kraken_fetcher.py
Fetches OHLCV data from Kraken via ccxt — no API key required.
"""
import os, time, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import ccxt
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
from loguru import logger
from config.settings import EXCHANGE_ID, TRADING_PAIRS, TIMEFRAME, HISTORY_DAYS, DATA_DIR


def get_exchange():
    exchange = getattr(ccxt, EXCHANGE_ID)({"enableRateLimit": True, "rateLimit": 3000})
    logger.info(f"Connected to {exchange.name}")
    return exchange


def fetch_ohlcv(exchange, symbol, timeframe=TIMEFRAME, days=HISTORY_DAYS):
    since_ms = int((datetime.utcnow() - timedelta(days=days)).timestamp() * 1000)
    all_candles = []
    logger.info(f"Fetching {symbol} [{timeframe}] — {days} days of history...")

    while True:
        try:
            candles = exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=since_ms, limit=720)
        except ccxt.RateLimitExceeded:
            logger.warning("Rate limit hit — sleeping 10s")
            time.sleep(10)
            continue
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {e} — retrying in 5s")
            time.sleep(5)
            continue

        if not candles:
            break
        all_candles.extend(candles)
        last_ts = candles[-1][0]
        if last_ts >= int((datetime.utcnow() - timedelta(hours=2)).timestamp() * 1000):
            break
        since_ms = last_ts + 1
        time.sleep(exchange.rateLimit / 1000)

    if not all_candles:
        logger.error(f"No data returned for {symbol}")
        return pd.DataFrame()

    df = pd.DataFrame(all_candles, columns=["timestamp", "open", "high", "low", "close", "volume"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
    df = df.drop_duplicates("timestamp").sort_values("timestamp").reset_index(drop=True)
    logger.success(f"{symbol}: {len(df)} candles ({df['timestamp'].iloc[0].date()} -> {df['timestamp'].iloc[-1].date()})")
    return df


def save_data(df, symbol):
    os.makedirs(DATA_DIR, exist_ok=True)
    safe_name = symbol.replace("/", "_")
    path = Path(DATA_DIR) / f"{safe_name}_{TIMEFRAME}.csv"
    df.to_csv(path, index=False)
    logger.info(f"Saved -> {path}")
    return path


def load_data(symbol):
    safe_name = symbol.replace("/", "_")
    path = Path(DATA_DIR) / f"{safe_name}_{TIMEFRAME}.csv"
    if path.exists():
        df = pd.read_csv(path, parse_dates=["timestamp"])
        logger.info(f"Loaded cached data for {symbol} ({len(df)} rows)")
        return df
    logger.info(f"No cache found for {symbol} — fetching from Kraken")
    exchange = get_exchange()
    df = fetch_ohlcv(exchange, symbol)
    if not df.empty:
        save_data(df, symbol)
    return df


def fetch_all_pairs(force_refresh=False):
    exchange = get_exchange()
    data = {}
    for symbol in TRADING_PAIRS:
        safe_name = symbol.replace("/", "_")
        path = Path(DATA_DIR) / f"{safe_name}_{TIMEFRAME}.csv"
        if path.exists() and not force_refresh:
            df = pd.read_csv(path, parse_dates=["timestamp"])
            logger.info(f"Loaded {symbol} from cache ({len(df)} rows)")
        else:
            df = fetch_ohlcv(exchange, symbol)
            if not df.empty:
                save_data(df, symbol)
        if not df.empty:
            data[symbol] = df
    logger.success(f"Loaded {len(data)}/{len(TRADING_PAIRS)} pairs")
    return data


if __name__ == "__main__":
    data = fetch_all_pairs(force_refresh=False)
    for sym, df in data.items():
        print(f"\n{sym}:\n{df.tail(3).to_string()}")
